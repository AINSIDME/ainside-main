# Product Downloads

Coloca aquí los archivos que se enviarán a los clientes después del pago:

## Estructura sugerida:

```
downloads/
├── basic/
│   ├── basic-plan.pdf
│   └── basic-files.zip
├── professional/
│   ├── professional-plan.pdf
│   └── professional-files.zip
└── premium/
    ├── premium-plan.pdf
    └── premium-files.zip
```

Los archivos deben estar accesibles públicamente en:
- https://ainside.me/downloads/basic/basic-plan.pdf
- https://ainside.me/downloads/basic/basic-files.zip
- etc.
