Place your onboarding screenshots here and name them:
- ts-1.png  (Entradas/Salidas, línea del trade y ATRStopL/S)
- ts-2.png  (Señal Short con ATRStopS)
- ts-3.png  (Evento EndOfDay)

PNG or JPG work. After adding files, redeploy the site so the gallery appears on /getting-started.
